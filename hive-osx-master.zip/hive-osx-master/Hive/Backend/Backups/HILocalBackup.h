//
//  HILocalBackup.h
//  Hive
//
//  Created by Jakub Suder on 13/02/14.
//  Copyright (c) 2014 Hive Developers. All rights reserved.
//

#import "HIBackupAdapter.h"

@interface HILocalBackup : HIBackupAdapter

@end
