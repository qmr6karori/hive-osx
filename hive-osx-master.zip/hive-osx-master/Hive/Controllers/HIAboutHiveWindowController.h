//
//  HIAboutHiveWindowController.h
//  Hive
//
//  Created by Jakub Suder on 18.02.2014.
//  Copyright (c) 2014 Hive Developers. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface HIAboutHiveWindowController : NSWindowController

@end
