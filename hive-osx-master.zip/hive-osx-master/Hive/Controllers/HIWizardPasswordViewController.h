//
//  HIWizardPasswordViewController.h
//  Hive
//
//  Created by Nikolaj Schumacher on 2014-01-19.
//  Copyright (c) 2014 Hive Developers. All rights reserved.
//

#import "HIWizardViewController.h"

/*
 First-run wizard page for picking a password.
 */
@interface HIWizardPasswordViewController : HIWizardViewController
@end
