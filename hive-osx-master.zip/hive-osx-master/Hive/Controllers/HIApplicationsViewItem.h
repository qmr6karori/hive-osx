//
//  HIApplicationsViewItem.h
//  Hive
//
//  Created by Jakub Suder on 27/02/14.
//  Copyright (c) 2014 Hive Developers. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface HIApplicationsViewItem : NSCollectionViewItem

@end
