//
//  SUCodeSigningVerifier.h
//  Hive
//
//  Created by Jakub Suder on 02.10.2013.
//  Copyright (c) 2013 Hive Developers. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SUCodeSigningVerifier : NSObject

@end
