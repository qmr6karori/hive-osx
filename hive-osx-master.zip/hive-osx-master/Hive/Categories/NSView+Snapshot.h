//
//  NSView+Snapshot.h
//  Hive
//
//  Created by Bazyli Zygan on 21.06.2013.
//  Copyright (c) 2013 Hive Developers. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSView (Snapshot)

- (NSImage *)snapshot;

@end
