/*
 Category to allow shaking a window (e.g. for wrong passwords).
 */
@interface NSWindow (HIShake)

- (void)hiShake;

@end
