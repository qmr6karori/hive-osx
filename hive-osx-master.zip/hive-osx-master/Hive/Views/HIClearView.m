#import "HIClearView.h"

@implementation HIClearView

- (void)drawRect:(NSRect)rect {
}

@end
