/*
A larger text field with padding above and below the input.
 */
@interface HIPaddedSecureTextFieldCell : NSSecureTextFieldCell
@end
