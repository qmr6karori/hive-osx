#import "HIClearView.h"

@interface HIBreadcrumbsView : HIClearView

@property (nonatomic, copy) NSArray *titles;
@property (nonatomic, assign) int activeIndex;

@end
