/*
 Pop up button with gray text to work as a label.
 */
@interface HILabelPopUpButton : NSPopUpButton
@end
