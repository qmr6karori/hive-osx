//
//  HIBackupStatusCellView.m
//  Hive
//
//  Created by Jakub Suder on 30.12.13.
//  Copyright (c) 2013 Hive Developers. All rights reserved.
//

#import "HIBackupStatusCellView.h"

@implementation HIBackupStatusCellView

@end
