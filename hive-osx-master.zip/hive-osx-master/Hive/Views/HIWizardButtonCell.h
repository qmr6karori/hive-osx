#import "HIDoneButtonCell.h"

/*
 Button style used for big wizard buttons.
 */
@interface HIWizardButtonCell : HIGradientButtonCell
@end
