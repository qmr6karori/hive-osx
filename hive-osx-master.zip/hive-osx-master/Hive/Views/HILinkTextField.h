/*
 * Displays a blue underlined link that can be clicked.
 */

@interface HILinkTextField : NSTextField

@property (nonatomic, copy) NSString *href;

@end
