//
//  HIFlippedView.m
//  Hive
//
//  Created by Bazyli Zygan on 17.09.2013.
//  Copyright (c) 2013 Hive Developers. All rights reserved.
//

#import "HIFlippedView.h"

@implementation HIFlippedView

- (BOOL)isFlipped {
    return YES;
}

@end
