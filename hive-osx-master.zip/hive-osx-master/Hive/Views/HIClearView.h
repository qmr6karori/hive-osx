/*
 Completely transparent view.
 */
@interface HIClearView : NSView
@end
