@interface HIEmptyTransactionsView : NSView

@end
