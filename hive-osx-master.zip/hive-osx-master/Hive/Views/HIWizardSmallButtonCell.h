#import "HIDoneButtonCell.h"

/*
 Button style for small buttons in wizard.
 */
@interface HIWizardSmallButtonCell : HIGradientButtonCell
@end
