//
//  HIBackupStatusCellView.h
//  Hive
//
//  Created by Jakub Suder on 30.12.13.
//  Copyright (c) 2013 Hive Developers. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface HIBackupStatusCellView : NSTableCellView

@property (nonatomic, strong) IBOutlet NSTextField *statusDetailsLabel;

@end
