//
//  HIBox.h
//  Hive
//
//  Created by Bazyli Zygan on 05.09.2013.
//  Copyright (c) 2013 Hive Developers. All rights reserved.
//

#import <Cocoa/Cocoa.h>

/*
 An NSBox with a custom rounded border and white background. Used in contact details views.
 */

@interface HIBox : NSView

@end
