//
//  HITextFieldCell.h
//  Hive
//
//  Created by Bazyli Zygan on 15.09.2013.
//  Copyright (c) 2013 Hive Developers. All rights reserved.
//

#import <Cocoa/Cocoa.h>

/*
 A cell used by HITextField.
 */

@interface HITextFieldCell : NSTextFieldCell

@end
