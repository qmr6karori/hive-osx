//
//  HISeparatorView.h
//  Hive
//
//  Created by Bazyli Zygan on 02.09.2013.
//  Copyright (c) 2013 Hive Developers. All rights reserved.
//

#import <Cocoa/Cocoa.h>

/*
 A view with a light gray background, used for some separator lines.
 */

@interface HISeparatorView : NSView

@end
